<?php
/**
 * @author: Viktor Jelínek (VikiJel)
 */